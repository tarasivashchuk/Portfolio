# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['portfolio']

package_data = \
{'': ['*']}

install_requires = \
['flask-wtf>=0.14.3,<0.15.0',
 'flask>=1.1.2,<2.0.0',
 'python-dotenv>=0.14.0,<0.15.0']

setup_kwargs = {
    'name': 'portfolio',
    'version': '0.2.0',
    'description': 'Website built using Flask in order to easily maintain an online portfolio in a modern and engaging fashion.',
    'long_description': None,
    'author': 'Taras Ivashchuk',
    'author_email': 'taras@tarasivashchuk.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
