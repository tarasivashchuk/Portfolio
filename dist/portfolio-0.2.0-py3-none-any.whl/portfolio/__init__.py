from pathlib import Path

project_dir = Path(__file__).parent.parent.parent.resolve()